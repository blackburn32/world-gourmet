# Guacamole

![Guacamole](https://source.unsplash.com/random/?guacamole)

**Ingredients**
- 2 ripe avocados
- 1 small red onion, finely diced
- 1 jalapeno pepper, seeded and diced
- 2 tablespoons lime juice
- 2 tablespoons chopped fresh cilantro
- 1 garlic clove, minced
- Salt and pepper to taste

**Instructions**
1. Cut the avocados in half and remove the pits. Scoop out the flesh into a bowl.
2. Mash the avocado with a fork until it reaches your desired consistency (chunky or smooth).
3. Stir in the diced red onion, jalapeno pepper, lime juice, chopped cilantro, and minced garlic.
4. Season with salt and pepper to taste.
5. Serve immediately with tortilla chips or use as a topping for tacos, salads, or sandwiches.

Enjoy your homemade guacamole!