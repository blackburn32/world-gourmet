# Tzatziki
Tzatziki is a traditional Greek dish. It's a sauce served with grilled meats, or it can be served as a dip.
![Tzatziki](https://source.unsplash.com/random/?tzatziki)

**Ingredients**
- 1 cucumber
- 1 1/2 cups Greek yogurt
- 2 cloves of garlic, minced
- 2 tbsp lemon juice
- 2 tbsp chopped fresh dill
- Salt and pepper to taste

**Instructions**
1. Grate the cucumber and drain it in a colander.
2. Combine the Greek yogurt, garlic, lemon juice, dill, and grated cucumber in a bowl.
3. Season it with salt and pepper. Chill for at least one hour before serving.