# Arrabbiata
Arrabbiata is an Italian pasta dish from Rome. It's made with garlic, tomatoes, and dried red chili peppers cooked in olive oil.
![Arrabbiata](https://source.unsplash.com/random/?arrabbiata)

**Ingredients**
- 2 cloves of garlic
- 1 can of diced tomatoes
- 1 tsp of dried red chili peppers
- 2 tbsp of olive oil
- Salt to taste
- 200 g of pasta

**Instructions**
1. Cook the pasta according to the package instructions.
2. In a separate pan, add the olive oil and sauté the garlic until it's golden.
3. Add the tomatoes and chili peppers, and simmer for 15 minutes.
4. Combine the sauce with the pasta, and adjust the seasoning with salt.
