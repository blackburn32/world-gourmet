# Poutine
Poutine is a classic Canadian dish originating from Quebec. It consists of crispy fries topped with cheese curds and smothered in a rich gravy.
![Poutine](https://source.unsplash.com/random/?poutine)

**Ingredients**
- 1 bag frozen French fries
- 2 cups cheese curds
- 1 packet Poutine gravy mix

**Instructions**
1. Bake or fry the French fries as instructed on the package until crispy.
2. Prepare the gravy according to the instructions on the packet.
3. Layer the fries and cheese curds in a dish. Pour hot gravy over the top to melt the cheese curds.
4. Dig in while it's hot!