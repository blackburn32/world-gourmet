# Couscous
Couscous is a traditional Berber dish of semolina which is cooked by steaming. It is traditionally served with a meat or vegetable stew spooned over it.
![Couscous](https://source.unsplash.com/random/?couscous)

**Ingredients**
- 1 cup of couscous
- 1 cup of boiling water
- 2 tablespoons of olive oil
- Salt to taste

**Instructions**
1. Place the couscous in a bowl.
2. Pour the boiling water over the couscous, then add the olive oil and salt.
3. Cover the bowl and let the couscous absorb the water for about 5 minutes.
4. Fluff with a fork before serving.