# Chicken Salad Sandwich

![Chicken Salad Sandwich](https://source.unsplash.com/random/?chicken-salad-sandwich)

**Ingredients:**
- 2 cups cooked chicken breast, shredded
- 1/2 cup mayonnaise
- 1/4 cup Greek yogurt
- 1 celery stalk, finely chopped
- 1/4 cup red onion, finely chopped
- 1/4 cup dried cranberries
- 1/4 cup chopped walnuts
- Salt and pepper, to taste
- 4-6 slices of bread
- Lettuce leaves and tomato slices for serving

**Instructions:**

1. In a mixing bowl, combine the shredded chicken, mayonnaise, Greek yogurt, celery, red onion, dried cranberries, and walnuts.
2. Stir everything together until well combined. Season with salt and pepper to taste.
3. Toast the bread slices if desired.
4. Spread a generous amount of the chicken salad mixture onto one side of each bread slice.
5. Top with lettuce leaves and tomato slices.
6. Place another bread slice on top to complete the sandwich.
7. Slice the sandwich in half or quarters, and it's ready to serve.

Enjoy your homemade Chicken Salad Sandwich! It's perfect for a quick and satisfying lunch or a picnic.