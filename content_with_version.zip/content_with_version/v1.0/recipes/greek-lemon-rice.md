# Greek Lemon Rice

Greek Lemon Rice is a popular side dish in Greece, packed with flavors of lemon, garlic and herbs, and often served with chicken or fish.
![Greek Lemon Rice](https://source.unsplash.com/random/?GreekLemonRice)

**Ingredients**
- 1.5 cups of Basmati rice
- 3 cups of chicken stock
- 4 cloves of garlic, finely chopped
- Juice of 2 lemons
- 1 teaspoon of dried oregano
- 2 tablespoons of olive oil
- Salt and pepper to taste

**Instructions**
1. Rinse the rice in cold water.
2. In a pot, heat the olive oil and sauté the garlic until fragrant.
3. Add the rice, chicken stock, lemon juice, oregano, salt, and pepper. Stir well.
4. Cover the pot and let it simmer until the rice is cooked, about 20 minutes.
5. Serve hot as a side dish.