# Asado
Asado is a barbecue technique and the social event of having or attending a barbecue in Argentina. It generally includes beef ribs, sausages, and other cuts which are cooked on a grill.
![Asado](https://source.unsplash.com/random/?asado)

**Ingredients**
- 2 kg beef ribs
- 1 kg chorizo sausages
- Salt
- Chimichurri sauce for serving

**Instructions**
1. Preheat a grill to medium high heat.
2. Season the beef ribs and sausages liberally with salt.
3. Cook the ribs and sausages on the grill, turning often, until browned and cooked to desired doneness.
4. Serve hot with chimichurri sauce.