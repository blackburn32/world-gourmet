# Caprese Salad
Caprese Salad is a classic Italian dish made with fresh tomatoes, mozzarella cheese, and basil. It's a light and refreshing salad that's perfect for summer.
![Caprese Salad](https://source.unsplash.com/random/?caprese-salad)

**Ingredients**
- 4 large tomatoes
- 8 ounces of mozzarella cheese
- Fresh basil leaves
- Extra virgin olive oil
- Balsamic glaze
- Salt and pepper to taste

**Instructions**
1. Slice the tomatoes and mozzarella cheese into 1/4 inch thick slices.
2. Arrange the tomato and mozzarella slices on a serving platter, alternating them.
3. Tuck fresh basil leaves in between the tomato and mozzarella slices.
4. Drizzle extra virgin olive oil over the salad.
5. Drizzle balsamic glaze over the salad.
6. Season with salt and pepper to taste.
7. Serve immediately and enjoy!
