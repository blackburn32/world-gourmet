# Jollof Rice
Jollof Rice is a popular West African dish. It's a one-pot rice dish cooked with tomatoes, peppers, and spices with a vibrant and warm flavor profile.  
![Jollof Rice](https://source.unsplash.com/random/?jollofrice)

**Ingredients**
- 2 cups of long grain parboiled rice
- 1 cup of tomato paste
- 1 green bell pepper
- 1 red bell pepper
- 2 medium onions
- 2 cloves of garlic
- 1 teaspoon of thyme
- 1 teaspoon of curry powder
- Salt to taste
- 3 cups of chicken broth
- 1/4 cup of vegetable oil

**Instructions**
1. Blend tomatoes, green bell pepper, red bell pepper and onions. Set aside.
2. Heat oil in a pan and fry the tomato blend with garlic, thyme and curry powder for about 15 minutes.
3. Add the rice and stir until it's well coated with the tomato blend.
4. Pour in the chicken broth, add salt to taste, and bring to a boil.
5. Reduce heat, cover and let simmer for about 30 minutes or until the rice is cooked.
6. Serve hot with your choice of protein.