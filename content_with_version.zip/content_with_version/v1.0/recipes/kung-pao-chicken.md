# Kung Pao Chicken
Kung Pao Chicken is a classic dish in Sichuan cuisine. It is a stir-fry dish with chicken, peanuts, vegetables and chili peppers.
![Kung Pao Chicken](https://source.unsplash.com/random/?kungpao)

**Ingredients**
- 300 g of chicken
- 1 cup of roasted peanuts
- 2 bell peppers
- 4 dried chili peppers
- 2 tablespoons of soy sauce
- 2 tablespoons of balsamic vinegar
- 1 teaspoon of cornstarch

**Instructions**
1. Cut the chicken into bite-sized pieces and marinate with 1 tbsp of soy sauce and cornstarch for 15 mins.
2. In a hot pan, stir-fry the dried chili peppers until they darken.
3. Add the chicken pieces and stir-fry until they are browned.
4. Add the bell peppers, reduce the heat, add the remaining soy sauce, vinegar, and peanuts, stir-frying for a further 2 minutes.