# Tacos el Pastor
Tacos el Pastor are a popular dish in central Mexico. The dish is made by cooking thin slices of marinated pork on a vertical rotisserie, similar to the way shawarma and gyros are made.
![Tacos el Pastor](https://source.unsplash.com/random/?tacos)

**Ingredients**
- 1 kg Pork shoulder
- 5 Guajillo chiles
- 1/4 cup white vinegar
- 3 cloves garlic
- 1 tsp dried oregano
- 1 tsp salt
- 1/2 tsp ground cumin
- 1/2 cup pineapple juice
- 1/2 cup water
- 1 lb. pineapple
- tortillas
- chopped cilantro and onions
- Lime wedges

**Instructions**

1. Marinate the pork shoulder in a mix of the spices, vinegar, garlic and pineapple juice for a minimum of 4 hours, ideally overnight.
2. Grill or sauté the pork until completely cooked through.
3. Slice and serve on tortillas. Top with pineapple, cilantro and onions.
4. Serve with lime wedges on the side.
