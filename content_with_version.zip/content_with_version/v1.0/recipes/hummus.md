# Hummus
Hummus is a dip or spread made from cooked, mashed chickpeas blended with tahini, lemon juice, and garlic
![Hummus](https://source.unsplash.com/random/?hummus)

**Ingredients**
- 1 cup cooked chickpeas
- 1/4 cup lemon juice
- 1/4 cup tahini
- 2 cloves garlic
- 1/4 tsp cumin
- Salt to taste
- Olive oil for serving

**Instructions**
1. In a blender combine the chickpeas, lemon juice, tahini, garlic, cumin, and salt.
2. Blend until creamy and well mixed.
3. Serve hummus with a drizzle of olive oil on top.