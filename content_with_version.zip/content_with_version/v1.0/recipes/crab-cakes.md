# Crab Cakes

![Crab Cakes](https://source.unsplash.com/random/?crabcakes)

**Ingredients:**
- 1 pound of lump crab meat
- 1/2 cup breadcrumbs
- 1/4 cup mayonnaise
- 1 tablespoon Dijon mustard
- 1 tablespoon Worcestershire sauce
- 1 tablespoon chopped fresh parsley
- 1 teaspoon Old Bay seasoning
- 1/2 teaspoon salt
- 1/4 teaspoon black pepper
- 1 egg, lightly beaten
- 2 tablespoons butter
- Lemon wedges, for serving

**Instructions:**
1. In a large bowl, gently pick through the crab meat to remove any shells.
2. In a separate bowl, mix together the breadcrumbs, mayonnaise, Dijon mustard, Worcestershire sauce, parsley, Old Bay seasoning, salt, black pepper, and beaten egg.
3. Add the breadcrumb mixture to the crab meat and gently fold until well combined.
4. Divide the mixture into 8 equal portions and shape each portion into a patty.
5. In a large skillet, melt the butter over medium heat. Cook the crab cakes for about 4-5 minutes on each side, or until golden brown and crispy.
6. Serve the crab cakes hot with lemon wedges on the side.

Enjoy your delicious homemade crab cakes!