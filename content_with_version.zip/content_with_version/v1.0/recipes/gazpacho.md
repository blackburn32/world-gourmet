# Gazpacho
Gazpacho is a soup made of raw blended vegetables. It's a classic of Spanish cuisine and is usually served cold.
![Gazpacho](https://source.unsplash.com/random/?gazpacho)

**Ingredients**
- 5 ripe tomatoes
- 1 cucumber
- 1 green bell pepper
- 2 cloves of garlic
- 1 tsp of salt
- 1/4 cup of olive oil
- 2 tbsp of sherry vinegar

**Instructions**
1. Combine all the ingredients in a blender and blend until smooth.
2. Season it with salt and pepper.
3. Chill in the refrigerator for at least 2 hours before serving.
