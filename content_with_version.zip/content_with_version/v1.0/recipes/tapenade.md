# Tapenade
Tapenade is a savoury dish from the south of France. It's a spread made from capers, black olives, and anchovies.
![Tapenade](https://source.unsplash.com/random/?tapenade)

**Ingredients**
- 2 cups of black olives
- 2 tablespoons of capers
- 2 anchovy fillets
- 2 cloves of garlic
- Juice of a lemon
- 1/4 cup of olive oil

**Instructions**
1. Combine all the ingredients in a food processor and blend until smooth.
2. Taste and adjust the seasoning with more capers, lemon juice, or garlic as needed.
