# Caesar Salad

![Caesar Salad](https://source.unsplash.com/random/?salad)

**Ingredients**
- 1 head of romaine lettuce, washed and torn into bite-sized pieces
- 1 cup of croutons
- 1/2 cup of grated Parmesan cheese
- 1/4 cup of [Caesar dressing](/recipes/caesar-dressing)
- 1 lemon, juiced
- Salt and black pepper to taste

**Instructions**
1. In a large salad bowl, combine the romaine lettuce, croutons, and grated Parmesan cheese.
2. Drizzle the Caesar dressing over the salad and squeeze the lemon juice over it.
3. Toss the salad gently to evenly coat the lettuce with the dressing and lemon juice.
4. Season with salt and black pepper to taste.
5. Serve the Caesar salad immediately and enjoy!