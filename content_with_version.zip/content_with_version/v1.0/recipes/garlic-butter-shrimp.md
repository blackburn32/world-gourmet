# Garlic Butter Shrimp

![Garlic Butter Shrimp](https://source.unsplash.com/random/?garlicbuttershrimp)

**Ingredients**
- 1 pound of raw shrimp, peeled and deveined
- 4 tablespoons of butter
- 4 cloves of garlic, minced
- 1 tablespoon of lemon juice
- Salt and pepper to taste
- Fresh parsley, chopped (for garnish)

**Instructions**
1. In a large skillet, melt the butter over medium heat.
2. Add the minced garlic to the skillet and saut� for about 1 minute until fragrant.
3. Season the shrimp with salt and pepper, then add them to the skillet.
4. Cook the shrimp for about 2-3 minutes on each side until they turn pink and opaque.
5. Drizzle the lemon juice over the shrimp and stir to combine.
6. Remove the skillet from heat and garnish with fresh parsley.
7. Serve the garlic butter shrimp hot with your favorite side dishes.

Enjoy your delicious Garlic Butter Shrimp!