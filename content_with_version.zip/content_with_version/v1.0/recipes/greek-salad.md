# Greek Salad

![Greek Salad](https://source.unsplash.com/random/?greeksalad)

**Ingredients**
- 2 large tomatoes, diced
- 1 cucumber, diced
- 1 red onion, thinly sliced
- 1 green bell pepper, diced
- 1 cup Kalamata olives, pitted
- 1 cup feta cheese, crumbled
- 2 tablespoons extra virgin olive oil
- 2 tablespoons red wine vinegar
- 1 teaspoon dried oregano
- Salt and pepper to taste

**Instructions**
1. In a large bowl, combine the tomatoes, cucumber, red onion, green bell pepper, and Kalamata olives.
2. In a small bowl, whisk together the olive oil, red wine vinegar, dried oregano, salt, and pepper.
3. Pour the dressing over the salad and toss to combine.
4. Sprinkle the crumbled feta cheese over the salad just before serving.
5. Serve chilled and enjoy!

**Note:** You can add some fresh herbs like parsley or mint for extra flavor if desired.