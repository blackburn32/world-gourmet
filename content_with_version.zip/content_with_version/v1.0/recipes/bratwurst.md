# Bratwurst

Bratwurst is a type of German sausage made from pork, beef, or veal. Its name derives from old German, Brät- "finely chopped meat", and Wurst, "sausage".

![Bratwurst](https://source.unsplash.com/random/?bratwurst)

**Ingredients**
- 4 bratwurst sausages
- 4 hoagie rolls
- 1 tablespoon oil
- 2 onions, sliced
- 1 cup beef broth
- 2 bottles of beer
- Mustard for serving

**Instructions**
1. In a large skillet, heat the oil over medium heat.
2. Once hot, add in the sliced onions and sauté until just caramelized.
3. Place the bratwurst in the skillet and brown on each side.
4. After browning, add the beer and beef broth.
5. Let simmer on medium heat for about 15 minutes, or until the bratwursts are cooked through.
6. Serve hot on hoagie rolls with caramelized onions and mustard.