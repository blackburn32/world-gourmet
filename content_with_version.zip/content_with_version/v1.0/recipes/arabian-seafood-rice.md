
# Arabian Seafood Rice

Arabian Seafood Rice, or Sayadieh, is a popular seafood dish in the Middle East, a perfect combination of spices, rice, and fish, garnished with fried onions and served with a tahini sauce.
![Arabian Seafood Rice](https://source.unsplash.com/random/?ArabianSeafoodRice)

**Ingredients**
- 2 cups of Basmati rice
- 500g of white fish fillets
- 1 large onion, thinly sliced
- 4 cups of water
- 2 tablespoons of olive oil
- Salt and pepper to taste
- 1 teaspoon of turmeric

**Instructions**
1. Rinse the rice in cold water.
2. In a pot, heat the olive oil and sauté the onions until golden brown. Remove half of the onions and set aside.
3. Add the fish, turmeric, salt, and pepper to the pot and top with water. Let it simmer for 15 minutes.
4. Remove the fish and add the rice to the pot. Cover and let it cook for 20 minutes.
5. Serve the rice topped with the fish fillets and the reserved onions.
